<?php
	include("sitemaster.php");
	session_destroy();
	echo '<script>window.location.href="../";</script>';
?>