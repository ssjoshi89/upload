<?php include("sitemaster.php"); ?>
<!DOCTYPE html>
<html lang="en" class="js">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <!-- Fav Icon  -->
	<link rel="shortcut icon" type="image/png" href="../../img/hsbc.png">
    <!-- Page Title  -->
    <title>ChaosArmor</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="../assets/css/dashlite.css?ver=3.2.3">
    <link id="skin-default" rel="stylesheet" href="../assets/css/theme.css?ver=3.2.3">
	
	<script type="text/javascript">
		function isNumberKey(txt, evt) {
		  var charCode = (evt.which) ? evt.which : evt.keyCode;
		  if (charCode == 46) {
			return false;
		  } else {
			if (charCode > 31 &&
			  (charCode < 48 || charCode > 57))
			  return false;
		  }
		  return true;
		}		
  </script>
</head>