<?php
	include("../../sitemaster.php");
	
	if(!isset($_SESSION['id']))
	{
		session_destroy();
		header("Location: ../index.php");
	}
?>