	<!-- @@ Change Pwd Modal @e -->
    <div class="modal fade" role="dialog" id="chgpwd">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
                <div class="modal-body modal-body-lg">
                    <h5 class="title">Change Password</h5>
                    <ul class="nk-nav nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#changepwd">Update Passcode</a>
                        </li>
                    </ul><!-- .nav-tabs -->
                    <div class="tab-content">
                        <div class="tab-pane active" id="personal">
                        <form method="post">
                            <div class="row gy-4">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label" for="full-name">Old Passcode <font color="red">*</font></label>
                                        <input type="password" class="form-control form-control-sm" name="oldpwd" placeholder="Old Password Here" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label" for="phone-no">New Passcode <font color="red">*</font></label>
                                        <input type="password" class="form-control form-control-sm" name="newpwd" placeholder="New Password Here" required>
                                    </div>
                                </div>
								<div class="col-md-6">
                                    <div class="form-group">
                                        <label class="form-label" for="phone-no">Confirm New Passcode <font color="red">*</font></label>
                                        <input type="password" class="form-control form-control-sm" name="cnfrmpwd" placeholder="Confirm New Password Here" required>
                                    </div>
                                </div>
                                
								<div class="col-12">
                                    <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                        <li>
                                            <input type="submit" data-bs-dismiss="modal" class="btn btn-lg btn-primary" name="updtPwd" value="Confirm & Update">
                                        </li>
                                        <li>
                                            <a href="#" data-bs-dismiss="modal" class="link link-light">Cancel</a>
                                        </li>
                                    </ul>
                                </div>
                                
                            </div>
							
						</form>
							
							
                        </div><!-- .tab-pane -->
                        
                    </div><!-- .tab-content -->
                </div><!-- .modal-body -->
            </div><!-- .modal-content -->
        </div><!-- .modal-dialog -->
    </div><!-- .modal -->

<!-- JavaScript -->
    <script src="../assets/js/bundle.js?ver=3.2.3"></script>
    <script src="../assets/js/scripts.js?ver=3.2.3"></script>
    <script src="../assets/js/charts/gd-invest.js?ver=3.2.3"></script>
	<script src="../assets/js/libs/datatable-btns.js?ver=3.2.3"></script>



<?php
	if(isset($_POST['updtPwd']))
	{
		$oldpwd = isset($_POST['oldpwd']) ? mysqli_real_escape_string($con,$_POST['oldpwd']) :  "";
		$newpwd = isset($_POST['newpwd']) ? mysqli_real_escape_string($con,$_POST['newpwd']) :  "";
		$cnfrmpwd = isset($_POST['cnfrmpwd']) ? mysqli_real_escape_string($con,$_POST['cnfrmpwd']) :  "";
		
		if($newpwd==$cnfrmpwd)
		{
			$sql="call updtPwd(:usrid,:oldpwd,:newpwd);";
			$sth = $con1->prepare($sql);
			
			$sth->bindParam(':usrid', $_SESSION['id']);
			$sth->bindParam(':oldpwd', $oldpwd);
			$sth->bindParam(':newpwd', $newpwd);
			
			$sth->execute();
			$flag=$sth->fetch();
			
			if ($flag[0]=="True")
			{
				echo "<script>alert('Passcode Updated Successfully!!!');</script>";
			}
			else if ($flag[0]=="Roll")
			{
				echo "<script>alert('Something went Wrong!!!');</script>";
			}
			else if ($flag[0]=="False")
			{
				echo "<script>alert('Incorrect Old Password!!!');</script>";
			}
		}
		else
		{
			echo "<script>alert('New Passwords Not Matched!!!');</script>";
		}
	}
?>	