<!-- footer @s -->
    <div class="nk-footer bg-white">
        <div class="container-fluid">
            <div class="nk-footer-wrap">
                <div class="nk-footer-copyright"> &copy; <script> document.write(new Date().getFullYear()) </script>  ChaosArmor. All Rights Reserved. </div>                        
            </div>
        </div>
    </div>
<!-- footer @e -->